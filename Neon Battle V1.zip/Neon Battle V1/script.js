const board = document.getElementById("board");
const statusText = document.getElementById("status");
const popup = document.getElementById("popup");
const popupMessage = document.getElementById("popupMessage");
const playAgain = document.getElementById("playAgain");
const burst = document.getElementById("burst");

let currentPlayer = "X";
let gameState = ["", "", "", "", "", "", "", "", ""];
let gameActive = true;

const winningConditions = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6],
];

for (let i = 0; i < 9; i++) {
  const cell = document.createElement("div");
  cell.classList.add("cell");
  cell.dataset.index = i;
  board.appendChild(cell);
}

const cells = document.querySelectorAll(".cell");

function handleCellClick(e) {
  const index = e.target.dataset.index;
  if (!gameActive || gameState[index] !== "") return;

  gameState[index] = currentPlayer;
  e.target.textContent = currentPlayer;
  e.target.classList.add(currentPlayer);

  if (checkWin()) {
    showPopup(`🎉 Player ${currentPlayer} Wins!`);
    triggerBurst();
    gameActive = false;
    return;
  }

  if (!gameState.includes("")) {
    showPopup("😎 It's a Draw!");
    gameActive = false;
    return;
  }

  currentPlayer = currentPlayer === "X" ? "O" : "X";
  statusText.textContent = `Player ${currentPlayer}'s turn`;
}

function checkWin() {
  return winningConditions.some(condition => {
    const [a, b, c] = condition;
    if (
      gameState[a] &&
      gameState[a] === gameState[b] &&
      gameState[a] === gameState[c]
    ) {
      condition.forEach(i => cells[i].classList.add("winner"));
      return true;
    }
    return false;
  });
}

function resetGame() {
  currentPlayer = "X";
  gameState = ["", "", "", "", "", "", "", "", ""];
  gameActive = true;
  statusText.textContent = "Player X's turn";
  cells.forEach(cell => {
    cell.textContent = "";
    cell.className = "cell";
  });
  popup.classList.remove("show");
}

function showPopup(message) {
  popupMessage.textContent = message;
  popup.classList.add("show");
}

function triggerBurst() {
  burst.classList.remove("active");
  void burst.offsetWidth; // reset animation
  burst.classList.add("active");
}

cells.forEach(cell => cell.addEventListener("click", handleCellClick));
playAgain.addEventListener("click", resetGame);